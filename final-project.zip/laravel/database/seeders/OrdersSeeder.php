<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class OrdersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('order')->insert([
            [
            'user_id' => 1,
            'product_id' => 1,
            'subtotal' => Str::random(10),
            'tax' => Str::random(10),
            'total' => Str::random(10),
            'discount' => Str::random(10),
            'quantity' => Str::random(10)
           ],
           [
            'user_id' => 2,
            'product_id' => 2,
            'subtotal' => Str::random(10),
            'tax' => Str::random(10),
            'total' => Str::random(10),
            'discount' => Str::random(10),
            'quantity' => Str::random(10)
           ],
           [
            'user_id' => 3,
            'product_id' => 3,
            'subtotal' => Str::random(10),
            'tax' => Str::random(10),
            'total' => Str::random(10),
            'discount' => Str::random(10),
            'quantity' => Str::random(10)
           ],
        ]);
    }
}
