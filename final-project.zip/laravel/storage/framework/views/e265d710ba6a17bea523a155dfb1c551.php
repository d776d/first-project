
<?php $__env->startSection('content'); ?>
<div style="padding: left 16px;">
<center>
    <h2>Welcome</h2>
    <p>Lorem ipsum dsa, dolorem id autem sed vel.</p>
</center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/home/index.blade.php ENDPATH**/ ?>